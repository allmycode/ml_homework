function g = gr(X)
  if (X >= 0.5) 
      g = 1;
  else 
    g = 0;
  end
end
